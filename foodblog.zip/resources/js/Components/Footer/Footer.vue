<template>
    <div class="w-100 text-center py-5 border-t-2">
        Copyright &copy;
    </div>
</template>

<script setup>
</script>